<?php 

	defined('ABSPATH') or die("Bye bye");
	define('RUTA',plugin_dir_path(__FILE__));

	if (!defined('WP_UNINSTALL_PLUGIN')) {
	    die;
	}

?>